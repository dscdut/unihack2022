<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta name="facebook-domain-verification" content="ujebofckwbk28epz4ncab7xjyw31ut" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="pingback" href="https://www.pulse.vn/xmlrpc.php" />
	<meta name='robots' content='max-image-preview:large' />

	<!-- This site is optimized with the Yoast SEO plugin v14.3 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Pulse Active</title>
	<meta name="robots" content="noindex, follow" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Pulse Active" />
	<meta property="og:site_name" content="Pulse Active" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.pulse.vn/#website","url":"https://www.pulse.vn/","name":"Pulse Active","description":"We Create Moments","potentialAction":[{"@type":"SearchAction","target":"https://www.pulse.vn/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Pulse Active &raquo; Feed" href="https://www.pulse.vn/feed/" />
<link rel="alternate" type="application/rss+xml" title="Pulse Active &raquo; Comments Feed" href="https://www.pulse.vn/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.pulse.vn\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.6"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://www.pulse.vn/wp-includes/css/dist/block-library/style.min.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://www.pulse.vn/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='image-hover-effects-css-css'  href='https://www.pulse.vn/wp-content/plugins/mega-addons-for-visual-composer/css/ihover.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='style-css-css'  href='https://www.pulse.vn/wp-content/plugins/mega-addons-for-visual-composer/css/style.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-latest-css'  href='https://www.pulse.vn/wp-content/plugins/mega-addons-for-visual-composer/css/font-awesome/css/all.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/magnific-popup/css/magnific-popup.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://www.pulse.vn/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=5.4.7' type='text/css' media='all' />
<link rel='stylesheet' id='tm-timeline-css-css'  href='https://www.pulse.vn/wp-content/plugins/tm-timeline/css/tm-timeline.css?ver=1.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://www.pulse.vn/wp-content/themes/united/css/bootstrap/bootstrap.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-select-css'  href='https://www.pulse.vn/wp-content/themes/united/css/bootstrap-select/bootstrap-select.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css'  href='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/owl-carousel/css/owl-theme.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='peicons-css'  href='https://www.pulse.vn/wp-content/themes/united/css/pe-icon-7-stroke/css/pe-icon-7-stroke.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='https://www.pulse.vn/wp-content/themes/united/core/includes/fontawesome/css/font-awesome.min.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='simple-icons-css'  href='https://www.pulse.vn/wp-content/themes/united/core/includes/simple/simple-line-icons.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='united-style-css'  href='https://www.pulse.vn/wp-content/themes/united/css/style.css?ver=5.7.6' type='text/css' media='all' />
<style id='united-style-inline-css' type='text/css'>
body{ font-family:Montserrat,Arial,sans-serif; color:#777; font-size:13px; letter-spacing:0em; }a {color:#000000;}a:hover {color:#666666;}h1 a{ color:#333; }h2 a{ color:#333; }h3 a{ color:#333; }h4 a{ color:#3334; }h5 a{ color:#333; }h6 a{ color:#333; }
@media screen and (min-width:901px){h1{ font-size:42px; }h2{ font-size:37px; }h3{ font-size:28px; }h4{ font-size:24px; }h5{ font-size:16px; }h6{ font-size:14px; }}.font-1, .button{ font-family:Montserrat,Arial,sans-serif; }.header-wrapper{}.header-spacer{}#header-sticky{background-color: #be967f;	} #header{	}
.header-info,.header-info a{color: rgba(255,255,255,0.7);	}.header-info a:hover{color:#ffffff;	}.site-logo, .site-logo:hover{ font-weight:500; letter-spacing:0.15em; color:#303133; font-family:Montserrat,Arial,sans-serif; font-size:24px; text-transform:uppercase; }.title-bar--page{background-color: #c4c4c4;}.title-bar--archive-works{background-color: #333;}.title-bar--work{background-color: #333;	}
@media screen and (min-width:801px){	.header-home.fixed .site-logo span,	.header-inside.fixed .site-logo span{	font-size: 85%;	}}a,
				.text-primary,
				.text-primary_h:hover,
				.text-primary_b:before,
				.text-primary_a:after,
				.list > li > a:hover,
				.pager li > a:hover,
				.pager li > a:hover .icon,
				.pagination_primary > li:first-child > a:hover,
				.pagination_primary > li:first-child > a:hover .icon,
				.pagination_primary > li:last-child > a:hover,
				.pagination_primary > li:last-child > a:hover .icon,
				.search-close:hover,
				.breadcrumb > li > a:hover,
				.sp-arrow:hover,
				.header .social-links > li > a:hover {color: #fadf06;}


				.bg-primary,
				.bg-primary_h:hover,
				.bg-primary_b:before,
				.bg-primary_a:after,
				.pagination_primary > .active > a,
				.pagination_primary > .active > span,
				.pagination_primary > .active > a,
				.pagination_primary > .active > span,
				.pagination_primary > li > a:hover,
				.pagination_primary > li > a:focus,
				.dropcap_primary:first-letter,
				.tooltip-1 .tooltip-inner,
				.btn-primary,
				input[type=button],
				input[type=submit],
				input[type=button],
				input[type=submit],
				.forms__label-check-1:after,
				.forms__label-radio-2:before,
				.panel-default > .panel-heading,
				.b-team .social-net,
				.section-social-net__link:hover,
				.b-isotope-grid__item:hover b-isotope-grid__wrap-info,
				.b-isotope-grid_mod-a .b-isotope-grid__inner:hover b-isotope-grid__wrap-info,
				.hvr-shutter-in-vertical,
				.b-pricing:before,
				.owl-theme_pagin_act_prim .owl-controls .owl-page.active span,
				.owl-theme_pagin_act_prim .owl-controls .owl-page:hover span,
				.list-tags__link:hover,
				.b-isotope-grid_mod-a .b-isotope-grid__item:hover .b-isotope-grid__wrap-info,
				.dark_bg .owl-theme .owl-controls .owl-page.active span, .dark_bg .owl-theme .owl-controls .owl-page:hover span,
				.header_mod-a .navbar .main-menu > li.active:before,
				.header_mod-a .navbar .main-menu > li:hover:before {background-color: #fadf06;}


				.border_prim,
				.border_prim_h:hover,
				.pagination > .active > a,
				.page-numbers.current,
				.pagination > .active > span,
				.pagination a:hover,
				.pagination span:hover,
				.pagination a:focus,
				.pagination span:focus,
				.progress_border_primary,
				.btn-primary,
				input[type=button],
				input[type=submit],
				.forms__label-radio-2:before,
				.list-tags__link:hover {border-color: #fadf06;}

				.border-t_prim,
				.border-t_prim_h:hover,
				.tooltip-1.top .tooltip-arrow,
				.tooltip-1.top-left .tooltip-arrow,
				.tooltip-1.top-right .tooltip-arrow,
				.navbar .navbar-nav > li > a:hover,
				.navbar .navbar-nav > li.current_page_item > a {border-top-color: #fadf06;}

				.border-r_prim,
				.border-r_prim_h:hover,
				.tooltip-1.right .tooltip-arrow,
				.b-progress-list__item,
				.b-brands-2 {border-right-color: #fadf06;}

				.border-b_prim,
				.border-b_prim_h:hover,
				.tooltip-1.bottom .tooltip-arrow,
				.tooltip-1.bottom-left .tooltip-arrow,
				.tooltip-1.bottom-right .tooltip-arrow,
				.table_primary > thead > tr > th,
				.collapse.in,
				.pagination > li > a:hover,
				.pagination > li > span:hover,
				.pagination > li > a:focus,
				.pagination > li > span:focus {border-bottom-color: #fadf06;}

				.border-l_prim,
				.border-l_prim_h:hover,
				.tooltip-1.left .tooltip-arrow,
				.border-left_primary:before,
				blockquote,
				.b-brands-2 {border-left-color: #fadf06;}

				blockquote:before {
				  text-shadow: -2px -2px 0 #fadf06, -2px -1px 0 #fadf06, -2px 0px 0 #fadf06, -2px 1px 0 #fadf06, -2px 2px 0 #fadf06, -1px -2px 0 #fadf06, -1px -1px 0 #fadf06, -1px 0px 0 #fadf06, -1px 1px 0 #fadf06, -1px 2px 0 #fadf06, 0px -2px 0 #fadf06, 0px -1px 0 #fadf06, 0px 0px 0 #fadf06, 0px 1px 0 #fadf06, 0px 2px 0 #fadf06, 1px -2px 0 #fadf06, 1px -1px 0 #fadf06, 1px 0px 0 #fadf06, 1px 1px 0 #fadf06, 1px 2px 0 #fadf06, 2px -2px 0 #fadf06, 2px -1px 0 #fadf06, 2px 0px 0 #fadf06, 2px 1px 0 #fadf06, 2px 2px 0 #fadf06;
				}

				.b-contact__icon {box-shadow: 25px 15px 0 -5px #fadf06;}


				.text-second,
				.text-second_h:hover,
				.link-tooltip-2,
				.forms__label-check-2:after,
				.pagination_secondary > li:first-child > a:hover,
				.pagination_secondary > li:first-child > a:hover .icon,
				.pagination_secondary > li:last-child > a:hover,
				.pagination_secondary > li:last-child > a:hover .icon {color: #55c2eb;}

				.bg-second,
				.bg-second_h:hover,
				.tooltip-2 .tooltip-inner,
				.dropcap_secondary:first-letter,
				.pagination_secondary > .active > a,
				.pagination_secondary > .active > span,
				.pagination_secondary > .active > a,
				.pagination_secondary > .active > span,
				.pagination_secondary > li > a:hover,
				.pagination_secondary > li > a:focus,
				.forms__label-radio-1:before {background-color: #55c2eb;}

				.border_second,
				.border_second_h:hover,
				.progress_border_secondary,
				.pagination_secondary > .active > a,
				.pagination_secondary > .active > span,
				.pagination_secondary > .active > a,
				.pagination_secondary > .active > span,
				.pagination_secondary > li > a:hover,
				.pagination_secondary > li > a:focus,
				.forms__label-radio-1:before {border-color: #55c2eb;}

				.border-t_second,
				.border-t_second_h:hover,
				.tooltip-2.top .tooltip-arrow,
				.tooltip-2.top-left .tooltip-arrow,
				.tooltip-2.top-right .tooltip-arrow {border-top-color: #55c2eb;}

				.border-r_second,
				.border-r_second_h:hover,
				.tooltip-2.right .tooltip-arrow {border-right-color: #55c2eb;}

				.border-l_second,
				.border-l_second_h:hover,
				.tooltip-2.left .tooltip-arrow {border-left-color: #55c2eb;}

				.border-b_second,
				.border-b_second_h:hover,
				.tooltip-2.bottom .tooltip-arrow,
				.tooltip-2.bottom-left .tooltip-arrow,
				.tooltip-2.bottom-right .tooltip-arrow,
				.table_secondary > thead > tr > th {border-bottom-color: #55c2eb;}.button--fill.button--1{ background:#00bd9c; }.button--outline.button--1{ border-color:#00bd9c; color:#00bd9c; }.button-hover--fill.button-hover--1:hover{ background: #00bd9c; }.button-hover--outline.button-hover--1:hover{ border-color: #00bd9c; color: #00bd9c; }.button--fill.button--2{ background: #333333; }.button--outline.button--2{ border-color: #333333; color:#333333; }.button-hover--fill.button-hover--2:hover{ background: #333333; }.button-hover--outline.button-hover--2:hover{ border-color: #333333; color: #333333; }.button--fill.button--3{ background: #9c9c9c; }.button--outline.button--3{ border-color:#9c9c9c; color:#9c9c9c; }.button-hover--fill.button-hover--3:hover{ background: #9c9c9c; }.button-hover--outline.button-hover--3:hover{ border-color: #9c9c9c; color: #9c9c9c; }#footer, #footer a{ font-family:Montserrat,Arial,sans-serif; font-size:14px; letter-spacing:0em; color:#777; font-weight:100; text-transform:uppercase; }#footer h1, #footer h2, #footer h3, #footer h4, #footer h5, #footer h6{ font-family:Montserrat,Arial,sans-serif; font-size:14px; letter-spacing:0em; color:#e2e2e2; font-weight:600; text-transform:uppercase; }#footer{	}.footer-overlay{background-color: rgba(0,0,0,0.85) !important;	}.copyright-wrapper{}#footer a {color:#777777;	}#footer a:hover {color:#666666;	}.service-title{ font-family:Montserrat,Arial,sans-serif; }
</style>
<link rel='stylesheet' id='united-style-responsive-css'  href='https://www.pulse.vn/wp-content/themes/united/css/style-responsive.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='msl-main-css'  href='https://www.pulse.vn/wp-content/plugins/master-slider/public/assets/css/masterslider.main.css?ver=3.5.8' type='text/css' media='all' />
<link rel='stylesheet' id='msl-custom-css'  href='https://www.pulse.vn/wp-content/uploads/master-slider/custom.css?ver=1.3' type='text/css' media='all' />
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<link rel="https://api.w.org/" href="https://www.pulse.vn/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.pulse.vn/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.pulse.vn/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.6" />
<script>var ms_grabbing_curosr = 'https://www.pulse.vn/wp-content/plugins/master-slider/public/assets/css/common/grabbing.cur', ms_grab_curosr = 'https://www.pulse.vn/wp-content/plugins/master-slider/public/assets/css/common/grab.cur';</script>
<meta name="generator" content="MasterSlider 3.5.8 - Responsive Touch Image Slider | avt.li/msf" />
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://www.pulse.vn/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PX9TPD2');</script>
<!-- End Google Tag Manager -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167290846-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167290846-1');
</script>
<link rel="icon" href="https://www.pulse.vn/wp-content/uploads/2020/10/cropped-Pulse-Active-512-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.pulse.vn/wp-content/uploads/2020/10/cropped-Pulse-Active-512-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.pulse.vn/wp-content/uploads/2020/10/cropped-Pulse-Active-512-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.pulse.vn/wp-content/uploads/2020/10/cropped-Pulse-Active-512-270x270.png" />
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="error404 _masterslider _ms_version_3.5.8 header-- wpb-js-composer js-comp-ver-5.4.7 vc_responsive">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PX9TPD2"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

	
	
	<!-- Header -->
		 <!-- ==========================-->
        <!-- SEARCH MODAL-->
        <!-- ==========================-->
        <div class="header-search open-search">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1">
                        <div class="navbar-search">
                            <form class="search-global" action="https://www.pulse.vn/">
                                <input class="search-global__input" type="text" placeholder="Type to search" autocomplete="off" name="s" value="" />
                                <button class="search-global__btn"><i class="icon stroke icon-Search"></i>
                                </button>
                                <div class="search-global__note">Begin typing your search above and press return to search.</div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <button class="search-close close" type="button"><i class="fa fa-times"></i>
            </button>
        </div>
        <!-- ==========================-->
        <!-- MOBILE MENU-->
        <!-- ==========================-->
        <div data-off-canvas="mobile-slidebar left overlay">

           <ul class="yamm main-menu nav navbar-nav"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-131"><a href="https://www.pulse.vn/">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-327"><a href="https://www.pulse.vn/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1176"><a href="https://www.pulse.vn/services/">Services</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-519"><a href="#">Work</a>
<ul class="dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-323"><a href="https://www.pulse.vn/events/">Events</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1416"><a href="https://www.pulse.vn/case-study/">Case Study</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-518"><a href="https://www.pulse.vn/artists/">Artists</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1477"><a href="https://www.pulse.vn/positive/">+Positive</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-362"><a href="https://www.pulse.vn/partnership/">Partnership</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-363"><a href="https://www.pulse.vn/jobs/">JOBS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-311"><a href="/2018/">News</a>
<ul class="dropdown-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-947"><a href="/2018/">2018</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-948"><a href="/2019/">2019</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1103"><a href="/2020">2020</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1739"><a href="/2021">2021</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-313"><a href="https://www.pulse.vn/contact-us/">Contact</a></li>
<li class="pll-parent-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-1579"><a href="#pll_switcher"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" alt="English" width="16" height="11" style="width: 16px; height: 11px;" /></a>
<ul class="dropdown-menu">
	<li class="lang-item lang-item-22 lang-item-en current-lang no-translation lang-item-first menu-item menu-item-type-custom menu-item-object-custom menu-item-home dropdown-submenu menu-item-1579-en"><a href="https://www.pulse.vn/" hreflang="en-US" lang="en-US"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" alt="English" width="16" height="11" style="width: 16px; height: 11px;" /></a></li>
	<li class="lang-item lang-item-25 lang-item-vi no-translation menu-item menu-item-type-custom menu-item-object-custom dropdown-submenu menu-item-1579-vi"><a href="https://www.pulse.vn/vi/home-tieng-viet/" hreflang="vi" lang="vi"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAFsSURBVHjaYvzPgAD/UNlYEUAAmuTYAAAQhAEYqF/zFbe50RZ1cMmS9TLi0pJLRjZohAMTGFUN9HdnHgEE1sDw//+Tp0ClINW/f4NI9d////3+f+b3/1+////+9f/XL6A4o6ws0AaAAGIBm/0fRTVQ2v3Pf97f/4/9Aqv+DdHA8Ps3UANAALEAMSNQNdDGP3+ALvnf8vv/t9//9X/////7f+uv/4K//iciNABNBwggsJP+/IW4kuH3n//1v/8v+wVSDURmv/57//7/CeokoKFA0wECiAnkpL9/wH4CO+DNr/+VQA1A9PN/w6//j36CVIMRxEkAAQR20m+QpSBXgU0CuSTj9/93v/8v//V/xW+48UBD/zAwAAQQSAMzOMiABoBUswCd8ev/M7A669//OX7///Lr/x+gBlCoAJ0DEEAgDUy//zBISoKNAfoepJNRFmQkyJecfxj4/kDCEIiAigECiPErakTiiWMIAAgwAB4ZUlqMMhQQAAAAAElFTkSuQmCC" alt="Tiếng Việt" width="16" height="11" style="width: 16px; height: 11px;" /></a></li>
</ul>
</li>
</ul>
        </div>
        <!-- ==========================-->
        <!-- FULL SCREEN MENU-->
        <!-- ==========================-->
        <div class="wrap-fixed-menu" id="fixedMenu">
            <nav class="fullscreen-center-menu">

                <div class="menu-main-menu-container">

                    <ul class="yamm main-menu nav navbar-nav"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-131"><a href="https://www.pulse.vn/">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-327"><a href="https://www.pulse.vn/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1176"><a href="https://www.pulse.vn/services/">Services</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-519"><a href="#">Work</a>
<ul class="dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-323"><a href="https://www.pulse.vn/events/">Events</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1416"><a href="https://www.pulse.vn/case-study/">Case Study</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-518"><a href="https://www.pulse.vn/artists/">Artists</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1477"><a href="https://www.pulse.vn/positive/">+Positive</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-362"><a href="https://www.pulse.vn/partnership/">Partnership</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-363"><a href="https://www.pulse.vn/jobs/">JOBS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-311"><a href="/2018/">News</a>
<ul class="dropdown-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-947"><a href="/2018/">2018</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-948"><a href="/2019/">2019</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1103"><a href="/2020">2020</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1739"><a href="/2021">2021</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-313"><a href="https://www.pulse.vn/contact-us/">Contact</a></li>
<li class="pll-parent-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-1579"><a href="#pll_switcher"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" alt="English" width="16" height="11" style="width: 16px; height: 11px;" /></a>
<ul class="dropdown-menu">
	<li class="lang-item lang-item-22 lang-item-en current-lang no-translation lang-item-first menu-item menu-item-type-custom menu-item-object-custom menu-item-home dropdown-submenu menu-item-1579-en"><a href="https://www.pulse.vn/" hreflang="en-US" lang="en-US"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" alt="English" width="16" height="11" style="width: 16px; height: 11px;" /></a></li>
	<li class="lang-item lang-item-25 lang-item-vi no-translation menu-item menu-item-type-custom menu-item-object-custom dropdown-submenu menu-item-1579-vi"><a href="https://www.pulse.vn/vi/home-tieng-viet/" hreflang="vi" lang="vi"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAFsSURBVHjaYvzPgAD/UNlYEUAAmuTYAAAQhAEYqF/zFbe50RZ1cMmS9TLi0pJLRjZohAMTGFUN9HdnHgEE1sDw//+Tp0ClINW/f4NI9d////3+f+b3/1+////+9f/XL6A4o6ws0AaAAGIBm/0fRTVQ2v3Pf97f/4/9Aqv+DdHA8Ps3UANAALEAMSNQNdDGP3+ALvnf8vv/t9//9X/////7f+uv/4K//iciNABNBwggsJP+/IW4kuH3n//1v/8v+wVSDURmv/57//7/CeokoKFA0wECiAnkpL9/wH4CO+DNr/+VQA1A9PN/w6//j36CVIMRxEkAAQR20m+QpSBXgU0CuSTj9/93v/8v//V/xW+48UBD/zAwAAQQSAMzOMiABoBUswCd8ev/M7A669//OX7///Lr/x+gBlCoAJ0DEEAgDUy//zBISoKNAfoepJNRFmQkyJecfxj4/kDCEIiAigECiPErakTiiWMIAAgwAB4ZUlqMMhQQAAAAAElFTkSuQmCC" alt="Tiếng Việt" width="16" height="11" style="width: 16px; height: 11px;" /></a></li>
</ul>
</li>
</ul>
                </div>
            </nav>
            <button type="button" class="fullmenu-close"><i class="fa fa-times"></i></button>
        </div>



        <header class="header header-topbar-hidden header-boxed-width navbar-fixed-top header-background-trans header-navibox-1-left header-navibox-2-right">
            <div class="container container-boxed-width">
                <div class="top-bar">
                    <div class="container">
                        <div class="header-topbarbox-1">
                            <ul>
                                <li></li>
                            </ul>
                        </div>
                        <div class="header-topbarbox-2">
                                                    </div>
                    </div>
                </div>
                <nav class="navbar" id="nav">



                    <div class="header-navibox-1">
                        <!-- Mobile Trigger Start-->
                        <button class="menu-mobile-button visible-xs-block js-toggle-mobile-slidebar toggle-menu-button"><i class="toggle-menu-button-icon"><span></span><span></span><span></span><span></span><span></span><span></span></i></button>
                        <!-- Mobile Trigger End-->
                        <div class="ui-decor-1 ui-decor-1_sm"></div>
                        <a class="navbar-brand scroll" href="https://www.pulse.vn/"><img alt="logo" src="https://www.pulse.vn/wp-content/uploads/2018/09/logo-pulseactive2.png"/></a>
                                            </div>


                    <div class="header-navibox-2">
                        <ul class="yamm main-menu nav navbar-nav"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-131"><a href="https://www.pulse.vn/">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-327"><a href="https://www.pulse.vn/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1176"><a href="https://www.pulse.vn/services/">Services</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-519"><a href="#">Work</a>
<ul class="dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-323"><a href="https://www.pulse.vn/events/">Events</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1416"><a href="https://www.pulse.vn/case-study/">Case Study</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-518"><a href="https://www.pulse.vn/artists/">Artists</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1477"><a href="https://www.pulse.vn/positive/">+Positive</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-362"><a href="https://www.pulse.vn/partnership/">Partnership</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-363"><a href="https://www.pulse.vn/jobs/">JOBS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-311"><a href="/2018/">News</a>
<ul class="dropdown-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-947"><a href="/2018/">2018</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-948"><a href="/2019/">2019</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1103"><a href="/2020">2020</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1739"><a href="/2021">2021</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-313"><a href="https://www.pulse.vn/contact-us/">Contact</a></li>
<li class="pll-parent-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown-submenu menu-item-1579"><a href="#pll_switcher"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" alt="English" width="16" height="11" style="width: 16px; height: 11px;" /></a>
<ul class="dropdown-menu">
	<li class="lang-item lang-item-22 lang-item-en current-lang no-translation lang-item-first menu-item menu-item-type-custom menu-item-object-custom menu-item-home dropdown-submenu menu-item-1579-en"><a href="https://www.pulse.vn/" hreflang="en-US" lang="en-US"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC" alt="English" width="16" height="11" style="width: 16px; height: 11px;" /></a></li>
	<li class="lang-item lang-item-25 lang-item-vi no-translation menu-item menu-item-type-custom menu-item-object-custom dropdown-submenu menu-item-1579-vi"><a href="https://www.pulse.vn/vi/home-tieng-viet/" hreflang="vi" lang="vi"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAFsSURBVHjaYvzPgAD/UNlYEUAAmuTYAAAQhAEYqF/zFbe50RZ1cMmS9TLi0pJLRjZohAMTGFUN9HdnHgEE1sDw//+Tp0ClINW/f4NI9d////3+f+b3/1+////+9f/XL6A4o6ws0AaAAGIBm/0fRTVQ2v3Pf97f/4/9Aqv+DdHA8Ps3UANAALEAMSNQNdDGP3+ALvnf8vv/t9//9X/////7f+uv/4K//iciNABNBwggsJP+/IW4kuH3n//1v/8v+wVSDURmv/57//7/CeokoKFA0wECiAnkpL9/wH4CO+DNr/+VQA1A9PN/w6//j36CVIMRxEkAAQR20m+QpSBXgU0CuSTj9/93v/8v//V/xW+48UBD/zAwAAQQSAMzOMiABoBUswCd8ev/M7A669//OX7///Lr/x+gBlCoAJ0DEEAgDUy//zBISoKNAfoepJNRFmQkyJecfxj4/kDCEIiAigECiPErakTiiWMIAAgwAB4ZUlqMMhQQAAAAAElFTkSuQmCC" alt="Tiếng Việt" width="16" height="11" style="width: 16px; height: 11px;" /></a></li>
</ul>
</li>
</ul>                        <ul class="btn-menu">
                             
                                                     </ul>



                    </div>

                </nav>
            </div>
        </header>
        <div class="header-height"><!--do not delete this div--></div>
        <!-- end .header-->	<div class="l-theme">

		<div class="main-wrapper">
	<div class="container">
		<div id="content" class="row padding-xlarge">	

			<section class="error-404 not-found">
				<h1>404</h1>
				<p>The page you are looking for might have been removed, had its name changed, or is temporary unavaliable</p>

				<div><a class="btn btn-primary btn-lg" href="https://www.pulse.vn/">Homepage</a></div>
			</section><!-- .error-404 -->

		</div>
	</div>

	

		</div> <!-- end .main-wrapper-->
				<!-- Social profiles -->
		<div class="section-social-net text-center">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
						<h2 class="ui-title-block">Stay Connected With Us!</h2>
	                    <ul class="section-social-net__list list-inline"><li class="section-social-net__item  wow  fadeIn" data-wow-duration="1s" data-wow-delay="0.3s"><a class="section-social-net__link Instagram" href="https://www.instagram.com/pulse_active/" target="_blank">Instagram</a></li><li class="section-social-net__item  wow  fadeIn" data-wow-duration="1s" data-wow-delay="0.3s"><a class="section-social-net__link Facebook" href="https://www.facebook.com/pulse.vn/" target="_blank">Facebook</a></li><li class="section-social-net__item  wow  fadeIn" data-wow-duration="1s" data-wow-delay="0.3s"><a class="section-social-net__link Youtube" href="https://www.youtube.com/user/colormerun" target="_blank">Youtube</a></li></ul>                    </div>
                </div>
            </div>
        </div>
        
		<footer class="footer">
            <div class="container">
                <div class="footer__main">
                    <div class="row">

						<div class="col-md-12"><section class="footer-section"><ul></ul></section></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="copyright">Pulse Active (c) 2021. All Rights Reserved</div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- .footer-->
		</div>
		<!-- wrapper (.l-theme) -->
	<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/www.pulse.vn\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2.2' id='contact-form-7-js'></script>
<script type='text/javascript' id='the1_slider-js-extra'>
/* <![CDATA[ */
var the1Globals = {"ajaxUrl":"https:\/\/www.pulse.vn\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/slider/_frontend.js?ver=1.0' id='the1_slider-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/slider/js/jquery.sliderPro.min.js?ver=1.0' id='sliderpro-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/magnific-popup/js/jquery.magnific-popup.min.js?ver=1.0' id='magnific-popup-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/tilthovereffects/anime.min.js?ver=1.0' id='tilthovereffects-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/revealer/js/scrollMonitor.js?ver=1.0' id='revealer-scrollmonitor-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/revealer/js/main.js?ver=1.0' id='revealer-main-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/tilthovereffects/main.js?ver=1.0' id='tilthovereffects-main-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/scrollreveal/js/scrollreveal.min.js?ver=1.0' id='scroll-reveal-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/isotope/js/isotope.pkgd.min.js?ver=1.0' id='united-isotope-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/js_composer/assets/lib/waypoints/waypoints.min.js?ver=5.4.7' id='waypoints-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/typed.js?ver=1.0' id='typed-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/main-functions.js?ver=1.0' id='main-plugin-functions-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/comment-reply.min.js?ver=5.7.6' id='comment-reply-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/jquery/ui/accordion.min.js?ver=1.12.1' id='jquery-ui-accordion-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/jquery/ui/tabs.min.js?ver=1.12.1' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/themes/united/js/header.js?ver=1.0' id='united-header-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/themes/united/js/bootstrap/bootstrap.js?ver=1.0' id='bootstrap-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/plugins/themes1-united-core/plugins/owl-carousel/js/owl.carousel.js?ver=1.0' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/themes/united/js/bootstrap-select/bootstrap-select.js?ver=1.0' id='bootstrap-select-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-content/themes/united/js/functions.js?ver=1.0' id='united-functions-js'></script>
<script type='text/javascript' src='https://www.pulse.vn/wp-includes/js/wp-embed.min.js?ver=5.7.6' id='wp-embed-js'></script>
<script type='text/javascript'>
(function() {
				var expirationDate = new Date();
				expirationDate.setTime( expirationDate.getTime() + 31536000 * 1000 );
				document.cookie = "pll_language=en; expires=" + expirationDate.toUTCString() + "; path=/; secure; SameSite=Lax";
			}());
</script>
</body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/


Served from: www.pulse.vn @ 2022-04-27 01:09:46 by W3 Total Cache
-->